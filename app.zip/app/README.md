Code for Chat app built with React, Redux, Redux-Saga, and web sockets. 

[Watch the full tutorial!](https://youtu.be/x_fHXt9V3zQ)
