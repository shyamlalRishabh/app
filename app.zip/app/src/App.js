import React, { Component } from 'react';
import './App.css';
import { Sidebar } from "./containers/Sidebar"
import { MessagesList } from "./containers/MessagesList"
import { AddMessage } from "./containers/AddMessage"

class App extends Component {
  render() {
    return (
     <span>


      <div class="div3">

        <Sidebar />
        <section >

          <MessagesList  />
          <AddMessage />
        </section>
      </div>
      </span>

    );
  }
}

export default App;
