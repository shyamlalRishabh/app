export const ADD_MESSAGE = "ADD_MESSAGE"
export const MESSAGE_RECEIVED = "MESSAGE_RECEIVED"
export const ADD_USER = "ADD_USER"
export const USERS_LIST = "USERS_LIST"