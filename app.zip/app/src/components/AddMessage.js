import React from 'react';
import PropTypes from 'prop-types';
// import 'emoji-mart/css/emoji-mart.css'
// import { Picker } from 'emoji-mart'

const AddMessage = (props) => {
	let input

	return (
		
		// <section id="new-message">
		<div >

		<h1>Type message here:</h1>







		
			<textarea rows="3" cols="50" id="textsize"placeholder="Type message here.."
				
				onKeyPress={(e) => {
					if (e.key === 'Enter') {
						props.dispatch(input.value, 'ME:')
						input.value = ''
					}
				}}
				type="text"
				ref={(node) => {
					input = node
				}}
			/>
			
		{/* </section> */}
		</div>
	)
}

AddMessage.PropTypes = {
	dispatch: PropTypes.func.isRequired
}

export default AddMessage